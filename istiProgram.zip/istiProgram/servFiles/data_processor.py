##################################################
# data_processor.py - This file formats the
# downloaded data in preperation for PDF creation
# using the R scrip CreateReport.R
##################################################


#############################
# Necessary Package Importing
#############################

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from email.utils import COMMASPACE, formatdate
import subprocess
import csv
import pandas as pd
import numpy as np
import os


######################
# Function Definitions
######################


#This function takes in an old data file (to be the previous iteration)
#and the new data downloaded from limesurvey, and creates a file
#which labels the "new" entries.
def merge_data(oldfile,newfile,pers_info,schdirname):
	#read in the old data and the new data and drop 'newentry' tag
	pathname = os.path.join(os.path.dirname(os.path.abspath(__file__)),schdirname)
	print(pathname)
	if os.path.isfile('%s/%s' % (pathname,oldfile)):
		old_file = pd.read_csv('%s/%s' % (pathname,oldfile),sep=',')
		if 'newflag' in old_file.columns:
			old_file.drop('newflag', axis=1, inplace=True)
		new_file = pd.read_csv('%s/%s' % (pathname,newfile))
		if 'newflag' in new_file.columns:
			new_file.drop('newflag', axis=1, inplace=True)
		#concatenate the data
		df = pd.concat([old_file,new_file])
		df = df.reset_index(drop=True)
		#group by columns
		df_gpby = df.groupby(list(df.columns))
		#get index of unique records in terms of the columns
		idx = [x[0] for x in df_gpby.groups.values() if len(x) == 1]
		#filter
		new_entries = df.reindex(idx)
		new_entries.insert(0,'newflag',1)
		old_file.insert(0,'newflag',0)
		new_output = pd.concat([old_file,new_entries])
		right = pd.read_csv('%s/%s' % (pathname,pers_info))
		result = pd.merge(new_output,right,on='token')
		result.to_csv('%s/Working_Results.csv' % pathname,sep=',',index=False) #edit the name here
		new_file.to_csv('%s/LimeSurveyResults_old.csv' % pathname,sep=',',index=False)
	else:
		new_file = pd.read_csv('%s/%s' % (pathname,newfile))
		new_file['newflag'] = np.ones(len(new_file))
		right = pd.read_csv('%s/%s' % (pathname,pers_info))
		result = pd.merge(new_file,right,on='token')
		result.to_csv('%s/Working_Results.csv' % pathname,sep=',',index=False)
		new_file.to_csv('%s/LimeSurveyResults_old.csv' % pathname,sep=',',index=False)



#################
# Code to be Run
#################

def main():
	#Pull down data from limesurvey to R
	#run_R_API()
	merge_data("LimeSurveyResults_old.csv","LimeSurveyResults.csv","tokens.csv")

	#Start background process run_proc()
	#sched.start()
	

if __name__ == "__main__":
	main()

