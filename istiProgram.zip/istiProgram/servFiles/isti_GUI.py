#simple GUI to start server and add files
#!/usr/bin/env python

from Tkinter import *
from scp import SCPClient
import paramiko
import os
import fileinput
import server_setup

#Retrieval Functions
def run_command(command_string):
	(stdin,stdout,stderr) = ssh.exec_command(command_string,get_pty=True)
	for line in stdout.readlines():
		print(line)
	for line in stderr.readlines():
		print(line)


def submit_school_info(schfolder):
	#Establish connection to the server
	homedir = os.path.dirname(os.path.abspath(__file__))
	keypath = '%s/istiaws2.pem' % homedir

	chmod_command = 'chmod 400 "%s"' % keypath
	os.system(chmod_command)
	global ssh
	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect("ec2-54-213-159-110.us-west-2.compute.amazonaws.com",
	             username='ubuntu',
	             key_filename=keypath)
	print("Connection Successful")

	#Load in the School Specific Files

	run_command("mkdir -p %s" % schfolder)
	local_schfolder = os.path.join(os.path.dirname(os.path.abspath(__file__)),'..',schfolder)
	for filename in os.listdir(local_schfolder):
		with SCPClient(ssh.get_transport()) as scp:
			scp.put("%s/%s" % (local_schfolder,filename), "~/%s/%s" % (schfolder,filename) )
		if filename.startswith("server_main"):
			servmain_file = filename
	run_command("sudo python ~/%s/%s" % (schfolder,servmain_file))

	print("Adding Scheduler...")
	run_command('(crontab -l ; echo "TZ=America/New_York") | sort - | uniq - | crontab -')
	run_command('(crontab -l ; echo "0 13 * * * sudo /usr/bin/python ~/%s/%s") | sort - | uniq - | crontab -' % (schfolder,servmain_file))
	run_command('(crontab -l ; echo "0 18 * * * sudo /usr/bin/python ~/%s/%s") | sort - | uniq - | crontab -' % (schfolder,servmain_file))
	run_command('(crontab -l ; echo "0 3 * * * sudo /usr/bin/python ~/%s/%s") | sort - | uniq - | crontab -' % (schfolder,servmain_file))
	print("Complete.")

def create_GUI():
	#create window
	root = Tk()

	#Modify root window
	root.title("ISTI Automator")
	root.geometry("450x450")

	app = Frame(root)
	app.grid()

	#Add Labels
	label = Label(app, text = "Feedback Email Automator for ISTI",font=("Courier",16))
	label.grid()

	#Add Message for the user
	instructions = Message(app,text = "This is the main menu for starting the ISTI Email Automater.\n\n If this is the first time the app is being used, please initialize the automator with the button 'Initialize Server'. This should not be done more than once. \n\nTo add an additional school, please fill out the field below with the directory name containing the requisite school files:\n\n - CreateReport_*.R\n - Define*Domains.R\n - LimeSurvey_API*.R\n - server_main_*.py\n - tokens_*.csv\n\n\n")
	instructions.grid()

	#Add Buttons
	button1 = Button(app,text="Initialize server",command =server_setup.execute)
	button1.grid()

	#Add whitespace
	
	#School File Folder Name
	fldrname = Label(app,text="School Folder Name")
	fldrname.grid(row=5)
	fldrname_entry = Entry(app)
	fldrname_entry.grid(row=6,column=0)


	#Add School Button
	addsch = Button(app,text="Add School",command = lambda: submit_school_info(fldrname_entry.get()))
	addsch.grid(row=16)



	#Start the GUI
	root.mainloop()
		

def main():
	create_GUI()

if __name__ == "__main__":
	main()