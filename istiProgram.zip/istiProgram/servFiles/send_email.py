##########################################
# send_email.py - File which controls the 
# automated transfer of data/pdf output
# to emails and the s3 server
#########################################


#############################
# Necessary Package Importing
#############################
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from email.utils import COMMASPACE, formatdate
#from apscheduler.schedulers.background import BackgroundScheduler
import subprocess
import csv
import pandas as pd
import numpy as np
import os
import time


######################
# Function Definitions
######################

# This function defines an email sending mechanism
def send_mail(fromaddr,frompass,toaddr,subj,bod,fname,fpath):

	#This creates an email message object
	msg = MIMEMultipart()
	#Fills in email message parts
	msg['From'] = fromaddr
	msg['To'] = toaddr
	msg['Subject'] = subj
	#Attaches body to message
	body = bod
	msg.attach(MIMEText(body,'plain'))
	#Attaches file to message
	filename = fname
	attach_path = fpath
	attachment = open(attach_path,"rb")

	part = MIMEBase('application','octet-stream')
	part.set_payload((attachment).read())
	encoders.encode_base64(part)
	part.add_header('Content-Disposition',"attachment; filename = %s" % filename)

	msg.attach(part)
	#Sends out file 
	server = smtplib.SMTP('smtp.gmail.com',587)
	server.starttls()
	server.login(fromaddr,frompass)
	text = msg.as_string()
	server.sendmail(fromaddr,toaddr,text)
	server.quit()

#This function transfers data to the AWS S3 server for cloud storage
def s3_transfer(Rdf,program_name):
	mail_data = pd.read_csv(Rdf)

	if mail_data.shape != (2,2):
		name_series = mail_data['studteachname'].unique()
		
		for name in name_series:
			current_name = name.replace(" ","")
			os.system('mkdir /home/ubuntu/PDFs/%s' % current_name)
			os.system('mv /home/ubuntu/PDFs/*%s*.pdf /home/ubuntu/PDFs/%s/' % (current_name,current_name))
			command = 's3cmd sync /home/ubuntu/PDFs/%s "s3://cedristi/%s/"' % (current_name,program_name)
			os.system(command)
			os.system('sudo rm -rf /home/ubuntu/PDFs/%s' % current_name)
		timestr = time.strftime("%d-%m-%y_%H:%M:%S")
		os.system('mv Data/output.csv /home/ubuntu/Data/output%s.csv' % timestr)
		command2 = 's3cmd sync /home/ubuntu/Data "s3://cedristi/%s/"' % program_name
		os.system(command2)

#This code processes a single line from the R dataframe and designates email lists
def mail_list(Rdf,fromaddr,frompass):
	count = 0
	mail_data = pd.read_csv(Rdf)
	if mail_data.shape != (2,2):
		#Assume the following order: (idm,StEmail, StName, FIemail, FIname, Memail,Mname,Filename)
		rownum = mail_data.count()[1]
		print(os.getcwd())
		print(rownum)
		for i in range(0,rownum):
			subj_st = 'student teacher subject'
			subj_ment = 'mentor subject %s' % mail_data['studteachname'][i]
			subj_fi = 'field instructor subject %s' % mail_data['studteachname'][i]

			bod_st = 'student teacher body %s,%s,%s' % (mail_data['studteachname'][i],mail_data['fiteachname'][i],mail_data['mentteachname'][i])
			bod_ment = 'mentor teacher body %s,%s,%s' % (mail_data['studteachname'][i],mail_data['fiteachname'][i],mail_data['mentteachname'][i])
			bod_fi = 'field instructor body %s,%s,%s' % (mail_data['studteachname'][i],mail_data['fiteachname'][i],mail_data['mentteachname'][i])


			send_mail(fromaddr,frompass,mail_data['studteachemail'][i],subj_st,bod_st,mail_data['filename'][i],mail_data['filename'][i])
			print('Email to Student Teacher Successfully Sent...')
			if pd.isnull(mail_data['mentteachemail'][i]) == False:
				send_mail(fromaddr,frompass,mail_data['mentteachemail'][i],subj_ment,bod_ment,mail_data['filename'][i],mail_data['filename'][i])
			print('Email to Mentor Teacher Successfully Sent...')
			if pd.isnull(mail_data['fieldinstemail'][i]) == False:
				send_mail(fromaddr,frompass,mail_data['fieldinstemail'][i],subj_fi,bod_fi,mail_data['filename'][i],mail_data['filename'][i])
			print('Email to Field Instructor Successfully Sent...')
	if mail_data.shape == (2,2):
		print('No new email data to be sent.')


##################
# Code to be Run
##################

def main():
	mail_list('~/Data/output.csv','m.lee.wolff@gmail.com','!')
if __name__ == "__main__":
	main()

