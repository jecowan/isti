####################################
# server_main.py - This is the main
# file to be run within the AWS EC2
# server
####################################


#############################
# Necessary Package Importing
#############################
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from email.utils import COMMASPACE, formatdate
import subprocess
import csv
import pandas as pd
import numpy as np
import os
import time
import fileinput
import sys
sys.path.insert(0,'/home/ubuntu')
import data_processor
import schedule
import send_email

#################
# Code to be Run
#################

def report():
	print("Downloading LimeSurvey Results...")
	path = os.path.dirname(os.path.abspath(__file__))
	os.system('sudo Rscript %s/LimeSurveyAPI_CU.R' % path)

	print("Reformatting Downloaded Data...")
	data_processor.merge_data("LimeSurveyResults_old.csv","LimeSurveyResults.csv","tokens_CU.csv", path)

	print("Creating PDF Documents...")
	os.system('sudo Rscript %s/CreateCUReport.R' % path)
	
	print("Sending Emails...")
	send_email.mail_list('%s/../Data/output.csv' % path,'m.lee.wolff@gmail.com','malm4arush123740569!')
	send_email.s3_transfer('%s/../Data/output.csv' % path,'Central University')



def main():
	report()

if __name__ == "__main__":
	main()
	