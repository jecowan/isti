numq <- 9
numd <- 5
numd1q <- 3
numd2q <- 2
numd3q <- 1
numd4q <- 1
numd5q <- 2

domain.code <- data.frame(domain = c(rep(1, numd1q), rep(2,numd2q), rep(3,numd3q), rep(4,numd4q),rep(5,numd5q)), question = 1:numq)

question.names <- data.frame(
  question_name = c(
    question = c(1:9), 
    "Centering instruction on high expectations for student achievement",
    "Recognizing individual student learning needs and developing strategies to address those needs",
    "Using multiple student data elements to modify instruction and improve student learning",
    "Demonstrating effective teaching practices",
    "Providing clear and intentional focus on subject matter content and curriculum",
    "Fostering and managing a safe, positive learning environment",
    "Physical and emotional",
    "Communicating and collaborating with parents and the school community",
    "Exhibiting collaborative and collegial practices focused on improving instructional practice and student learning"))
domain.names <- data.frame(
  domain = c(1:5), 
  domain_name = c("Critical Thinking", "Communication",
                  "Time Management",
                  "Stamina",
                  "Professionalism"))

